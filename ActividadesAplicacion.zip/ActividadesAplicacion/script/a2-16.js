let a=0;
let b=10;
console.log('Incrementos:');
console.log('valor de a:   ',a, ' Inicial');
console.log('valor de ++a:   ',++a,' Incremento anterior');
console.log('valor de a:   ',a, ' Despues');
console.log('');
console.log('valor de a:   ',a, ' Inicial');
console.log('valor de a++:   ',a++, 'Incremento posterior');
console.log('valor de a:   ',a, ' Despues');




console.log('\n\n\nDecrementos:');
console.log(`Valor inicial de b:${b}.\nValor de --b:${--b}\tValor de b:${b}\nValor de b--:${b--}\tValor de b:${b} `);